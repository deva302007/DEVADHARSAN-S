<?php
declare(strict_types=1);

/*
 * InternHub PDO database connection.
 *
 * The existing database password from the supplied project is preserved.
 * If the hosting provider changes the MySQL password, update $dbPass here.
 */

$dbHost = 'db01.dbhost.dev';
$dbPort = '5051';
$dbName = 'db_454xyywur';
$dbUser = 'user_454xyywur';
$dbPass = 'p454xyywur';

$dsn = "mysql:host={$dbHost};port={$dbPort};dbname={$dbName};charset=utf8mb4";

try {
    if (!class_exists('PDO')) {
        throw new RuntimeException('PDO is not available in this PHP installation.');
    }

    if (!in_array('mysql', PDO::getAvailableDrivers(), true)) {
        throw new RuntimeException(
            'PDO MySQL is not loaded. Start PHP with pdo_mysql enabled.'
        );
    }

    $pdo = new PDO(
        $dsn,
        $dbUser,
        $dbPass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::ATTR_TIMEOUT => 10
        ]
    );

    $pdo->query('SELECT 1');
} catch (PDOException $e) {
    $code = 0;

    if (isset($e->errorInfo[1])) {
        $code = (int)$e->errorInfo[1];
    }

    http_response_code(500);

    $message = 'Database connection failed.';

    if ($code === 1045) {
        $message =
            'MySQL rejected the database username/password or the server host is not allowed. ' .
            'Verify the database credentials and remote-access permission in the hosting panel.';
    } elseif ($code === 1044) {
        $message =
            'The database user does not have permission to use the configured database.';
    } elseif ($code === 1049) {
        $message =
            'The configured database does not exist.';
    } elseif ($code === 2002 || $code === 2003) {
        $message =
            'The PHP server could not reach the MySQL server. Check the database host and port.';
    }

    error_log('InternHub PDO connection error: ' . $e->getMessage());

    echo '<!doctype html><html lang="en"><head><meta charset="utf-8">';
    echo '<meta name="viewport" content="width=device-width,initial-scale=1">';
    echo '<title>InternHub Database Error</title>';
    echo '<style>
        body{margin:0;padding:40px;background:#07111f;color:#eef6ff;font-family:Arial,sans-serif}
        .box{max-width:760px;margin:40px auto;background:#0d1b2d;border:1px solid #24354a;
        border-radius:16px;padding:28px;box-shadow:0 20px 60px #0005}
        h1{margin-top:0;color:#ff7d8a}.msg{padding:16px;border-radius:10px;
        background:#321722;border:1px solid #65303c;line-height:1.6}
        code{background:#16283c;padding:2px 6px;border-radius:5px}
    </style></head><body><div class="box">';
    echo '<h1>InternHub database connection failed</h1>';
    echo '<div class="msg">' . htmlspecialchars($message, ENT_QUOTES, 'UTF-8') . '</div>';
    echo '</div></body></html>';
    exit;
} catch (Throwable $e) {
    http_response_code(500);
    error_log('InternHub configuration error: ' . $e->getMessage());

    echo '<!doctype html><html lang="en"><head><meta charset="utf-8">';
    echo '<meta name="viewport" content="width=device-width,initial-scale=1">';
    echo '<title>InternHub Error</title></head><body>';
    echo '<h1>InternHub configuration error</h1>';
    echo '<p>' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8') . '</p>';
    echo '</body></html>';
    exit;
}
?>
