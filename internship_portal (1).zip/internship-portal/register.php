<?php
declare(strict_types=1);
session_start();

require_once __DIR__ . '/config/database.php';

$error = '';
$success = '';
$name = '';
$email = '';
$role = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? '';

    if ($name === '') {
        $error = 'Please enter your full name.';
    } elseif (strlen($name) > 100) {
        $error = 'Name is too long.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must contain at least 6 characters.';
    } elseif (!in_array($role, ['student', 'company'], true)) {
        $error = 'Please select a valid account type.';
    } else {
        try {
            $check = $pdo->prepare(
                'SELECT id FROM users WHERE email = ? LIMIT 1'
            );
            $check->execute([$email]);

            if ($check->fetch()) {
                $error = 'An account with this email already exists.';
            } else {
                $hash = password_hash($password, PASSWORD_DEFAULT);

                if ($hash === false) {
                    throw new RuntimeException('Password hashing failed.');
                }

                $pdo->beginTransaction();

                $stmt = $pdo->prepare(
                    'INSERT INTO users (name, email, password, role)
                     VALUES (?, ?, ?, ?)'
                );
                $stmt->execute([$name, $email, $hash, $role]);

                $userId = (int)$pdo->lastInsertId();

                if ($role === 'student') {
                    $profile = $pdo->prepare(
                        'INSERT INTO students (user_id) VALUES (?)'
                    );
                    $profile->execute([$userId]);
                } else {
                    $profile = $pdo->prepare(
                        'INSERT INTO companies (user_id, company_name)
                         VALUES (?, ?)'
                    );
                    $profile->execute([$userId, $name]);
                }

                $pdo->commit();

                $success = 'Account created successfully. You can now sign in.';
                $name = '';
                $email = '';
                $role = '';
            }
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log('InternHub registration error: ' . $e->getMessage());
            $error = 'Registration failed. Please try again.';
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Create Account - InternHub</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body class="auth-page">
<div class="auth-container">
<div class="auth-brand">
<a href="index.php" class="logo">Intern<span>Hub</span></a>
<h1>Start your journey.</h1>
<p>Create an account and connect with meaningful internship opportunities.</p>
</div>
<div class="auth-card">
<h2>Create Account</h2>
<p class="muted">Choose your role and enter your details.</p>
<?php if ($error !== ''): ?>
<div class="alert error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
<?php endif; ?>
<?php if ($success !== ''): ?>
<div class="alert success"><?= htmlspecialchars($success, ENT_QUOTES, 'UTF-8') ?></div>
<?php endif; ?>
<form method="post">
<label for="name">Full Name</label>
<input type="text" id="name" name="name" value="<?= htmlspecialchars($name, ENT_QUOTES, 'UTF-8') ?>"
placeholder="Enter your full name" required>
<label for="email">Email Address</label>
<input type="email" id="email" name="email" value="<?= htmlspecialchars($email, ENT_QUOTES, 'UTF-8') ?>"
placeholder="you@example.com" required>
<label for="password">Password</label>
<input type="password" id="password" name="password" minlength="6" placeholder="Minimum 6 characters" required>
<label for="role">Account Type</label>
<select id="role" name="role" required>
<option value="">Select account type</option>
<option value="student" <?= $role === 'student' ? 'selected' : '' ?>>Student</option>
<option value="company" <?= $role === 'company' ? 'selected' : '' ?>>Company</option>
</select>
<button type="submit" class="btn primary full">Create Account</button>
</form>
<p class="auth-bottom">Already have an account? <a href="login.php">Sign in</a></p>
</div>
</div>
</body>
</html>
