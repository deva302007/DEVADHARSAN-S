<?php
declare(strict_types=1);
session_start();
require_once __DIR__ . '/../config/database.php';

if (!isset($_SESSION['user_id'], $_SESSION['role']) || $_SESSION['role'] !== 'student') {
    header('Location: ../login.php');
    exit;
}

$userId = (int)$_SESSION['user_id'];
$message = '';
$error = '';
$student = [
    'name' => $_SESSION['name'] ?? '',
    'email' => $_SESSION['email'] ?? '',
    'phone' => '',
    'college' => '',
    'course' => '',
    'skills' => '',
    'bio' => '',
    'resume' => ''
];

try {
    $stmt = $pdo->prepare(
        'SELECT s.*, u.name, u.email
         FROM students s
         INNER JOIN users u ON s.user_id = u.id
         WHERE s.user_id = ?
         LIMIT 1'
    );
    $stmt->execute([$userId]);
    $found = $stmt->fetch();

    if ($found) {
        $student = array_merge($student, $found);
    } else {
        $create = $pdo->prepare(
            'INSERT INTO students (user_id) VALUES (?)'
        );
        $create->execute([$userId]);
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $phone = trim($_POST['phone'] ?? '');
        $college = trim($_POST['college'] ?? '');
        $course = trim($_POST['course'] ?? '');
        $skills = trim($_POST['skills'] ?? '');
        $bio = trim($_POST['bio'] ?? '');
        $resume = (string)($student['resume'] ?? '');

        if (isset($_FILES['resume']) && $_FILES['resume']['error'] !== UPLOAD_ERR_NO_FILE) {
            if ($_FILES['resume']['error'] !== UPLOAD_ERR_OK) {
                throw new RuntimeException('Resume upload failed.');
            }

            $extension = strtolower(
                pathinfo((string)$_FILES['resume']['name'], PATHINFO_EXTENSION)
            );

            if ($extension !== 'pdf') {
                throw new RuntimeException('Only PDF resumes are allowed.');
            }

            if ((int)$_FILES['resume']['size'] > 5 * 1024 * 1024) {
                throw new RuntimeException('Resume must be 5 MB or smaller.');
            }

            $uploadDir = __DIR__ . '/../uploads';

            if (!is_dir($uploadDir) && !mkdir($uploadDir, 0755, true)) {
                throw new RuntimeException('Unable to create upload directory.');
            }

            $fileName = 'resume_' . $userId . '_' . time() . '.pdf';
            $destination = $uploadDir . '/' . $fileName;

            if (!move_uploaded_file($_FILES['resume']['tmp_name'], $destination)) {
                throw new RuntimeException('Unable to save the uploaded resume.');
            }

            $resume = $fileName;
        }

        $update = $pdo->prepare(
            'UPDATE students
             SET phone = ?, college = ?, course = ?, skills = ?, bio = ?, resume = ?
             WHERE user_id = ?'
        );
        $update->execute([
            $phone,
            $college,
            $course,
            $skills,
            $bio,
            $resume,
            $userId
        ]);

        $stmt = $pdo->prepare(
            'SELECT s.*, u.name, u.email
             FROM students s
             INNER JOIN users u ON s.user_id = u.id
             WHERE s.user_id = ?
             LIMIT 1'
        );
        $stmt->execute([$userId]);
        $student = array_merge($student, $stmt->fetch() ?: []);

        $message = 'Profile updated successfully.';
    }
} catch (Throwable $e) {
    error_log('InternHub student profile error: ' . $e->getMessage());
    $error = $e instanceof RuntimeException
        ? $e->getMessage()
        : 'Unable to update your profile.';
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>My Profile - InternHub</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include __DIR__ . '/student_nav.php'; ?>
<main class="dashboard narrow">
<div class="page-heading">
<div><p class="eyebrow">PROFILE</p><h1>My Profile</h1><p>Keep your student information up to date.</p></div>
</div>

<?php if ($message !== ''): ?><div class="alert success"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
<?php if ($error !== ''): ?><div class="alert error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>

<div class="form-card">
<form method="post" enctype="multipart/form-data">
<div class="form-grid">
<div><label>Name</label><input type="text" value="<?= htmlspecialchars($student['name'] ?? '', ENT_QUOTES, 'UTF-8') ?>" disabled></div>
<div><label>Email</label><input type="email" value="<?= htmlspecialchars($student['email'] ?? '', ENT_QUOTES, 'UTF-8') ?>" disabled></div>
<div><label>Phone</label><input type="text" name="phone" value="<?= htmlspecialchars($student['phone'] ?? '', ENT_QUOTES, 'UTF-8') ?>"></div>
<div><label>College</label><input type="text" name="college" value="<?= htmlspecialchars($student['college'] ?? '', ENT_QUOTES, 'UTF-8') ?>"></div>
<div><label>Course</label><input type="text" name="course" value="<?= htmlspecialchars($student['course'] ?? '', ENT_QUOTES, 'UTF-8') ?>"></div>
<div><label>Skills</label><input type="text" name="skills" placeholder="PHP, MySQL, JavaScript" value="<?= htmlspecialchars($student['skills'] ?? '', ENT_QUOTES, 'UTF-8') ?>"></div>
</div>
<label>About You</label>
<textarea name="bio" rows="5" placeholder="Write a short introduction..."><?= htmlspecialchars($student['bio'] ?? '', ENT_QUOTES, 'UTF-8') ?></textarea>
<label>Resume (PDF, max 5 MB)</label>
<input type="file" name="resume" accept=".pdf,application/pdf">
<?php if (!empty($student['resume'])): ?><p class="small-text">Current resume uploaded.</p><?php endif; ?>
<button type="submit" class="btn primary">Save Profile</button>
</form>
</div>
</main>
</body>
</html>
