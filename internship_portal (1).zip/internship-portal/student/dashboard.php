<?php
declare(strict_types=1);
session_start();
require_once __DIR__ . '/../config/database.php';

if (!isset($_SESSION['user_id'], $_SESSION['role']) || $_SESSION['role'] !== 'student') {
    header('Location: ../login.php');
    exit;
}

$userId = (int)$_SESSION['user_id'];
$totalApplications = 0;
$shortlisted = 0;
$openInternships = 0;
$studentExists = false;
$dashboardError = '';

try {
    $stmt = $pdo->prepare(
        'SELECT id FROM students WHERE user_id = ? LIMIT 1'
    );
    $stmt->execute([$userId]);
    $studentExists = (bool)$stmt->fetch();

    if ($studentExists) {
        $stmt = $pdo->prepare(
            'SELECT COUNT(*)
             FROM applications a
             INNER JOIN students s ON s.id = a.student_id
             WHERE s.user_id = ?'
        );
        $stmt->execute([$userId]);
        $totalApplications = (int)$stmt->fetchColumn();

        $stmt = $pdo->prepare(
            "SELECT COUNT(*)
             FROM applications a
             INNER JOIN students s ON s.id = a.student_id
             WHERE s.user_id = ? AND a.status = 'Shortlisted'"
        );
        $stmt->execute([$userId]);
        $shortlisted = (int)$stmt->fetchColumn();
    }

    $stmt = $pdo->query(
        "SELECT COUNT(*) FROM internships WHERE status = 'Open'"
    );
    $openInternships = (int)$stmt->fetchColumn();
} catch (PDOException $e) {
    error_log('InternHub student dashboard error: ' . $e->getMessage());
    $dashboardError = 'Some dashboard information could not be loaded.';
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Student Dashboard - InternHub</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include __DIR__ . '/student_nav.php'; ?>
<main class="dashboard">
<div class="page-heading">
<div>
<p class="eyebrow">STUDENT DASHBOARD</p>
<h1>Welcome, <?= htmlspecialchars($_SESSION['name'] ?? 'Student', ENT_QUOTES, 'UTF-8') ?>.</h1>
<p>Manage your profile, discover internships and track your applications.</p>
</div>
<a href="internships.php" class="btn primary">Find Internships</a>
</div>

<?php if ($dashboardError !== ''): ?>
<div class="alert error"><?= htmlspecialchars($dashboardError, ENT_QUOTES, 'UTF-8') ?></div>
<?php endif; ?>

<?php if (!$studentExists): ?>
<div class="alert error">
Your student profile is missing. <a href="profile.php">Open your profile</a> to create it.
</div>
<?php endif; ?>

<div class="stats-grid">
<div class="stat-card"><span>Total Applications</span><strong><?= $totalApplications ?></strong></div>
<div class="stat-card"><span>Shortlisted</span><strong><?= $shortlisted ?></strong></div>
<div class="stat-card"><span>Open Internships</span><strong><?= $openInternships ?></strong></div>
</div>

<div class="quick-grid">
<a class="quick-card" href="profile.php"><h3>My Profile</h3><p>Update your education, skills, bio and resume.</p></a>
<a class="quick-card" href="internships.php"><h3>Browse Internships</h3><p>Search and explore available internship opportunities.</p></a>
<a class="quick-card" href="applications.php"><h3>My Applications</h3><p>Check the status of internships you have applied for.</p></a>
</div>
</main>
</body>
</html>
