<?php
declare(strict_types=1);
session_start();
require_once __DIR__ . '/../config/database.php';

if (!isset($_SESSION['user_id'], $_SESSION['role']) || $_SESSION['role'] !== 'student') {
    header('Location: ../login.php');
    exit;
}

$search = trim($_GET['search'] ?? '');
$location = trim($_GET['location'] ?? '');
$rows = [];
$error = '';

try {
    $sql = "SELECT i.*, c.company_name
            FROM internships i
            INNER JOIN companies c ON i.company_id = c.id
            WHERE i.status = 'Open'";
    $params = [];

    if ($search !== '') {
        $sql .= " AND (i.title LIKE ? OR i.description LIKE ? OR c.company_name LIKE ?)";
        $term = '%' . $search . '%';
        $params[] = $term;
        $params[] = $term;
        $params[] = $term;
    }

    if ($location !== '') {
        $sql .= ' AND i.location LIKE ?';
        $params[] = '%' . $location . '%';
    }

    $sql .= ' ORDER BY i.created_at DESC';

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log('InternHub internship listing error: ' . $e->getMessage());
    $error = 'Unable to load internships.';
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Internships - InternHub</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include __DIR__ . '/student_nav.php'; ?>
<main class="dashboard">
<div class="page-heading">
<div><p class="eyebrow">OPPORTUNITIES</p><h1>Find Internships</h1><p>Search opportunities that match your interests.</p></div>
</div>

<form class="search-bar" method="get">
<input type="text" name="search" placeholder="Search role, company or keyword" value="<?= htmlspecialchars($search, ENT_QUOTES, 'UTF-8') ?>">
<input type="text" name="location" placeholder="Location" value="<?= htmlspecialchars($location, ENT_QUOTES, 'UTF-8') ?>">
<button class="btn primary" type="submit">Search</button>
</form>

<?php if ($error !== ''): ?><div class="alert error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>

<div class="internship-grid">
<?php if (!$rows): ?>
<div class="detail-card"><h3>No internships found</h3><p>Try another keyword or location.</p></div>
<?php endif; ?>

<?php foreach ($rows as $row): ?>
<div class="internship-card">
<span class="status open">Open</span>
<h2><?= htmlspecialchars($row['title'], ENT_QUOTES, 'UTF-8') ?></h2>
<h4><?= htmlspecialchars($row['company_name'] ?? 'Company', ENT_QUOTES, 'UTF-8') ?></h4>
<p><?= htmlspecialchars($row['description'], ENT_QUOTES, 'UTF-8') ?></p>
<div class="tags">
<?php if (!empty($row['location'])): ?><span><?= htmlspecialchars($row['location'], ENT_QUOTES, 'UTF-8') ?></span><?php endif; ?>
<?php if (!empty($row['skills'])): ?><span><?= htmlspecialchars($row['skills'], ENT_QUOTES, 'UTF-8') ?></span><?php endif; ?>
</div>
<a class="btn primary" href="apply.php?id=<?= (int)$row['id'] ?>">View &amp; Apply</a>
</div>
<?php endforeach; ?>
</div>
</main>
</body>
</html>
