<?php
declare(strict_types=1);
session_start();
require_once __DIR__ . '/../config/database.php';

if (!isset($_SESSION['user_id'], $_SESSION['role']) || $_SESSION['role'] !== 'student') {
    header('Location: ../login.php');
    exit;
}

$applications = [];
$error = '';

try {
    $stmt = $pdo->prepare(
        'SELECT a.*, i.title, c.company_name
         FROM applications a
         INNER JOIN students s ON a.student_id = s.id
         INNER JOIN internships i ON a.internship_id = i.id
         INNER JOIN companies c ON i.company_id = c.id
         WHERE s.user_id = ?
         ORDER BY a.applied_at DESC'
    );
    $stmt->execute([(int)$_SESSION['user_id']]);
    $applications = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log('InternHub student applications error: ' . $e->getMessage());
    $error = 'Unable to load your applications.';
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Applications - InternHub</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include __DIR__ . '/student_nav.php'; ?>
<main class="dashboard">
<div class="page-heading">
<div><p class="eyebrow">TRACKING</p><h1>My Applications</h1><p>Track the progress of every internship application.</p></div>
</div>

<?php if ($error !== ''): ?><div class="alert error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>

<div class="table-card">
<table>
<thead><tr><th>Internship</th><th>Company</th><th>Applied On</th><th>Status</th></tr></thead>
<tbody>
<?php if (!$applications): ?>
<tr><td colspan="4">No applications yet. <a href="internships.php">Browse internships</a>.</td></tr>
<?php endif; ?>
<?php foreach ($applications as $row): ?>
<tr>
<td><?= htmlspecialchars($row['title'], ENT_QUOTES, 'UTF-8') ?></td>
<td><?= htmlspecialchars($row['company_name'], ENT_QUOTES, 'UTF-8') ?></td>
<td><?= htmlspecialchars(date('d M Y', strtotime((string)$row['applied_at'])), ENT_QUOTES, 'UTF-8') ?></td>
<td><span class="status"><?= htmlspecialchars($row['status'], ENT_QUOTES, 'UTF-8') ?></span></td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>
</main>
</body>
</html>
