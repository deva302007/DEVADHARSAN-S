<?php
declare(strict_types=1);
session_start();
require_once __DIR__ . '/../config/database.php';

if (!isset($_SESSION['user_id'], $_SESSION['role']) || $_SESSION['role'] !== 'student') {
    header('Location: ../login.php');
    exit;
}

$internshipId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?: 0;
$userId = (int)$_SESSION['user_id'];
$message = '';
$error = '';
$internship = null;
$studentId = 0;
$alreadyApplied = false;

try {
    if ($internshipId > 0) {
        $stmt = $pdo->prepare(
            "SELECT i.*, c.company_name
             FROM internships i
             INNER JOIN companies c ON i.company_id = c.id
             WHERE i.id = ? AND i.status = 'Open'
             LIMIT 1"
        );
        $stmt->execute([$internshipId]);
        $internship = $stmt->fetch();
    }

    $stmt = $pdo->prepare(
        'SELECT id FROM students WHERE user_id = ? LIMIT 1'
    );
    $stmt->execute([$userId]);
    $student = $stmt->fetch();

    if ($student) {
        $studentId = (int)$student['id'];
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && $internship && $studentId > 0) {
        $check = $pdo->prepare(
            'SELECT id FROM applications
             WHERE student_id = ? AND internship_id = ?
             LIMIT 1'
        );
        $check->execute([$studentId, $internshipId]);
        $alreadyApplied = (bool)$check->fetch();

        if ($alreadyApplied) {
            $message = 'You have already applied for this internship.';
        } else {
            $insert = $pdo->prepare(
                "INSERT INTO applications
                 (student_id, internship_id, status)
                 VALUES (?, ?, 'Applied')"
            );
            $insert->execute([$studentId, $internshipId]);
            $message = 'Application submitted successfully.';
            $alreadyApplied = true;
        }
    }
} catch (PDOException $e) {
    error_log('InternHub application error: ' . $e->getMessage());

    if ((int)($e->errorInfo[1] ?? 0) === 1062) {
        $message = 'You have already applied for this internship.';
        $alreadyApplied = true;
    } else {
        $error = 'Unable to process the application.';
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Apply - InternHub</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include __DIR__ . '/student_nav.php'; ?>
<main class="dashboard narrow">
<?php if (!$internship): ?>
<div class="alert error">Internship not found or no longer open.</div>
<?php else: ?>
<div class="detail-card">
<span class="status open">Open</span>
<h1><?= htmlspecialchars($internship['title'], ENT_QUOTES, 'UTF-8') ?></h1>
<h3><?= htmlspecialchars($internship['company_name'] ?? 'Company', ENT_QUOTES, 'UTF-8') ?></h3>
<p><?= nl2br(htmlspecialchars($internship['description'], ENT_QUOTES, 'UTF-8')) ?></p>
<div class="detail-info">
<p><strong>Location:</strong> <?= htmlspecialchars($internship['location'] ?? '', ENT_QUOTES, 'UTF-8') ?></p>
<p><strong>Skills:</strong> <?= htmlspecialchars($internship['skills'] ?? 'Not specified', ENT_QUOTES, 'UTF-8') ?></p>
<p><strong>Duration:</strong> <?= htmlspecialchars($internship['duration'] ?? 'Not specified', ENT_QUOTES, 'UTF-8') ?></p>
<p><strong>Stipend:</strong> <?= htmlspecialchars($internship['stipend'] ?? 'Not specified', ENT_QUOTES, 'UTF-8') ?></p>
</div>

<?php if ($error !== ''): ?><div class="alert error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
<?php if ($message !== ''): ?><div class="alert success"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>

<?php if (!$alreadyApplied && $studentId > 0 && $error === ''): ?>
<form method="post"><button class="btn primary" type="submit">Apply Now</button></form>
<?php elseif ($studentId <= 0): ?>
<div class="alert error">Your student profile is missing. Please open Profile and save it first.</div>
<?php endif; ?>
</div>
<?php endif; ?>
</main>
</body>
</html>
