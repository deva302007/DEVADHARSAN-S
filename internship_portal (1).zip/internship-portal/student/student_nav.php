<nav class="navbar dashboard-nav">
<div class="logo"><a href="../index.php">Intern<span>Hub</span></a></div>
<div class="nav-links">
<a href="dashboard.php">Dashboard</a>
<a href="profile.php">Profile</a>
<a href="internships.php">Internships</a>
<a href="applications.php">Applications</a>
<a href="../logout.php">Logout</a>
</div>
</nav>
