<?php
declare(strict_types=1);
session_start();

require_once __DIR__ . '/config/database.php';

if (isset($_SESSION['user_id'], $_SESSION['role'])) {
    if ($_SESSION['role'] === 'student') {
        header('Location: student/dashboard.php');
        exit;
    }
    if ($_SESSION['role'] === 'company') {
        header('Location: company/dashboard.php');
        exit;
    }
}

$error = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '') {
        $error = 'Please enter your email address.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif ($password === '') {
        $error = 'Please enter your password.';
    } else {
        try {
            $stmt = $pdo->prepare(
                'SELECT id, name, email, password, role
                 FROM users
                 WHERE email = ?
                 LIMIT 1'
            );
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if (!$user || !password_verify($password, (string)$user['password'])) {
                $error = 'Invalid email or password.';
            } elseif (!in_array($user['role'], ['student', 'company'], true)) {
                $error = 'This account has an invalid role.';
            } else {
                session_regenerate_id(true);

                $_SESSION['user_id'] = (int)$user['id'];
                $_SESSION['name'] = (string)$user['name'];
                $_SESSION['email'] = (string)$user['email'];
                $_SESSION['role'] = (string)$user['role'];

                header(
                    'Location: ' .
                    ($user['role'] === 'student'
                        ? 'student/dashboard.php'
                        : 'company/dashboard.php')
                );
                exit;
            }
        } catch (PDOException $e) {
            error_log('InternHub login error: ' . $e->getMessage());
            $error = 'Unable to log in because of a database error.';
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Login - InternHub</title>
<link rel="stylesheet" href="css/style.css">
<style>
.login-page{min-height:100vh;display:grid;place-items:center;padding:30px 18px}
.login-box{width:min(440px,100%);background:rgba(13,27,45,.96);border:1px solid var(--border);
border-radius:18px;padding:38px;box-shadow:0 25px 80px #0006}
.login-brand{text-align:center;margin-bottom:28px}.login-brand a{font-size:32px;font-weight:800}
.login-brand a span{color:var(--accent)}.login-brand h1{margin:18px 0 8px;font-size:25px}
.login-brand p{color:var(--muted);line-height:1.6;margin:0}.login-error{margin-bottom:20px;padding:13px 15px;
border-radius:9px;background:rgba(255,107,122,.1);border:1px solid rgba(255,107,122,.25);color:#ff9ba6}
.login-form label{display:block;margin:0 0 8px}.login-form input{width:100%;height:48px;margin-bottom:18px}
.login-form button{width:100%;height:48px;margin-top:4px}.login-register{text-align:center;color:var(--muted);margin:24px 0 0}
.login-register a{color:var(--accent);font-weight:700}
</style>
</head>
<body class="login-page">
<div class="login-box">
<div class="login-brand">
<a href="index.php">Intern<span>Hub</span></a>
<h1>Welcome back</h1>
<p>Sign in to continue to your internship dashboard.</p>
</div>
<?php if ($error !== ''): ?>
<div class="alert error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
<?php endif; ?>
<form class="login-form" method="post">
<label for="email">Email Address</label>
<input type="email" id="email" name="email" value="<?= htmlspecialchars($email, ENT_QUOTES, 'UTF-8') ?>"
placeholder="you@example.com" autocomplete="email" required>
<label for="password">Password</label>
<input type="password" id="password" name="password" placeholder="Enter your password"
autocomplete="current-password" required>
<button type="submit" class="btn primary">Sign In</button>
</form>
<p class="login-register">Don't have an account? <a href="register.php">Create an account</a></p>
</div>
</body>
</html>
