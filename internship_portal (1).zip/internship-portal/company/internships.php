<?php
declare(strict_types=1);
session_start();
require_once __DIR__ . '/../config/database.php';

if (!isset($_SESSION['user_id'], $_SESSION['role']) || $_SESSION['role'] !== 'company') {
    header('Location: ../login.php');
    exit;
}

$rows = [];
$error = '';

try {
    $stmt = $pdo->prepare(
        'SELECT i.*, COUNT(a.id) AS applicant_count
         FROM internships i
         LEFT JOIN applications a ON i.id = a.internship_id
         INNER JOIN companies c ON i.company_id = c.id
         WHERE c.user_id = ?
         GROUP BY i.id
         ORDER BY i.created_at DESC'
    );
    $stmt->execute([(int)$_SESSION['user_id']]);
    $rows = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log('InternHub company internships error: ' . $e->getMessage());
    $error = 'Unable to load your internships.';
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>My Internships - InternHub</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include __DIR__ . '/company_nav.php'; ?>
<main class="dashboard">
<div class="page-heading">
<div><p class="eyebrow">MANAGEMENT</p><h1>My Internships</h1><p>View the internships you have posted.</p></div>
<a class="btn primary" href="add_internship.php">Add New</a>
</div>
<?php if ($error !== ''): ?><div class="alert error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
<div class="table-card">
<table>
<thead><tr><th>Title</th><th>Location</th><th>Status</th><th>Applicants</th></tr></thead>
<tbody>
<?php if (!$rows): ?><tr><td colspan="4">You have not posted any internships yet.</td></tr><?php endif; ?>
<?php foreach ($rows as $row): ?>
<tr>
<td><?= htmlspecialchars($row['title'], ENT_QUOTES, 'UTF-8') ?></td>
<td><?= htmlspecialchars($row['location'], ENT_QUOTES, 'UTF-8') ?></td>
<td><span class="status <?= strtolower($row['status']) === 'open' ? 'open' : '' ?>"><?= htmlspecialchars($row['status'], ENT_QUOTES, 'UTF-8') ?></span></td>
<td><?= (int)$row['applicant_count'] ?></td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>
</main>
</body>
</html>
