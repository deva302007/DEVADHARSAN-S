<?php
declare(strict_types=1);
session_start();
require_once __DIR__ . '/../config/database.php';

if (!isset($_SESSION['user_id'], $_SESSION['role']) || $_SESSION['role'] !== 'company') {
    header('Location: ../login.php');
    exit;
}

$userId = (int)$_SESSION['user_id'];
$company = null;
$totalInternships = 0;
$totalApplicants = 0;
$error = '';

try {
    $stmt = $pdo->prepare(
        'SELECT id, company_name
         FROM companies
         WHERE user_id = ?
         LIMIT 1'
    );
    $stmt->execute([$userId]);
    $company = $stmt->fetch();

    if (!$company) {
        $stmt = $pdo->prepare(
            'INSERT INTO companies (user_id, company_name)
             VALUES (?, ?)'
        );
        $stmt->execute([$userId, $_SESSION['name'] ?? 'Company']);

        $company = [
            'id' => (int)$pdo->lastInsertId(),
            'company_name' => $_SESSION['name'] ?? 'Company'
        ];
    }

    $companyId = (int)$company['id'];

    $stmt = $pdo->prepare(
        'SELECT COUNT(*) FROM internships WHERE company_id = ?'
    );
    $stmt->execute([$companyId]);
    $totalInternships = (int)$stmt->fetchColumn();

    $stmt = $pdo->prepare(
        'SELECT COUNT(*)
         FROM applications a
         INNER JOIN internships i ON a.internship_id = i.id
         WHERE i.company_id = ?'
    );
    $stmt->execute([$companyId]);
    $totalApplicants = (int)$stmt->fetchColumn();
} catch (Throwable $e) {
    error_log('InternHub company dashboard error: ' . $e->getMessage());
    $error = 'Unable to load some dashboard information.';
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Company Dashboard - InternHub</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include __DIR__ . '/company_nav.php'; ?>
<main class="dashboard">
<div class="page-heading">
<div><p class="eyebrow">COMPANY DASHBOARD</p>
<h1>Welcome, <?= htmlspecialchars($company['company_name'] ?? $_SESSION['name'] ?? 'Company', ENT_QUOTES, 'UTF-8') ?>.</h1>
<p>Manage your internship opportunities and applicants.</p></div>
<a href="add_internship.php" class="btn primary">Post Internship</a>
</div>
<?php if ($error !== ''): ?><div class="alert error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
<div class="stats-grid">
<div class="stat-card"><span>Internships Posted</span><strong><?= $totalInternships ?></strong></div>
<div class="stat-card"><span>Total Applicants</span><strong><?= $totalApplicants ?></strong></div>
</div>
<div class="quick-grid">
<a class="quick-card" href="add_internship.php"><h3>Add Internship</h3><p>Create a new internship opportunity.</p></a>
<a class="quick-card" href="internships.php"><h3>My Internships</h3><p>View and manage your posted opportunities.</p></a>
<a class="quick-card" href="applicants.php"><h3>Applicants</h3><p>Review students and update application status.</p></a>
</div>
</main>
</body>
</html>
