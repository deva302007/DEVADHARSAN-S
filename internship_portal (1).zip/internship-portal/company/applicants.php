<?php
declare(strict_types=1);
session_start();
require_once __DIR__ . '/../config/database.php';

if (!isset($_SESSION['user_id'], $_SESSION['role']) || $_SESSION['role'] !== 'company') {
    header('Location: ../login.php');
    exit;
}

$error = '';
$applicants = [];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $applicationId = filter_input(INPUT_POST, 'application_id', FILTER_VALIDATE_INT) ?: 0;
        $status = trim($_POST['status'] ?? '');

        $allowed = [
            'Under Review',
            'Shortlisted',
            'Interview',
            'Selected',
            'Rejected'
        ];

        if ($applicationId > 0 && in_array($status, $allowed, true)) {
            $update = $pdo->prepare(
                'UPDATE applications a
                 INNER JOIN internships i ON a.internship_id = i.id
                 INNER JOIN companies c ON i.company_id = c.id
                 SET a.status = ?
                 WHERE a.id = ? AND c.user_id = ?'
            );
            $update->execute([
                $status,
                $applicationId,
                (int)$_SESSION['user_id']
            ]);
        }
    }

    $stmt = $pdo->prepare(
        'SELECT a.id, a.status, a.applied_at,
                u.name, u.email, i.title, s.skills, s.college
         FROM applications a
         INNER JOIN students s ON a.student_id = s.id
         INNER JOIN users u ON s.user_id = u.id
         INNER JOIN internships i ON a.internship_id = i.id
         INNER JOIN companies c ON i.company_id = c.id
         WHERE c.user_id = ?
         ORDER BY a.applied_at DESC'
    );
    $stmt->execute([(int)$_SESSION['user_id']]);
    $applicants = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log('InternHub applicants error: ' . $e->getMessage());
    $error = 'Unable to load applicants.';
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Applicants - InternHub</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include __DIR__ . '/company_nav.php'; ?>
<main class="dashboard">
<div class="page-heading">
<div><p class="eyebrow">APPLICATIONS</p><h1>Applicants</h1><p>Review applicants and update their application status.</p></div>
</div>
<?php if ($error !== ''): ?><div class="alert error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
<div class="table-card">
<table>
<thead><tr><th>Student</th><th>Internship</th><th>Skills</th><th>Applied</th><th>Status</th><th>Update</th></tr></thead>
<tbody>
<?php if (!$applicants): ?><tr><td colspan="6">No applicants yet.</td></tr><?php endif; ?>
<?php foreach ($applicants as $row): ?>
<tr>
<td><strong><?= htmlspecialchars($row['name'], ENT_QUOTES, 'UTF-8') ?></strong><br><small><?= htmlspecialchars($row['email'], ENT_QUOTES, 'UTF-8') ?></small></td>
<td><?= htmlspecialchars($row['title'], ENT_QUOTES, 'UTF-8') ?></td>
<td><?= htmlspecialchars($row['skills'] ?? 'Not added', ENT_QUOTES, 'UTF-8') ?></td>
<td><?= htmlspecialchars(date('d M Y', strtotime((string)$row['applied_at'])), ENT_QUOTES, 'UTF-8') ?></td>
<td><span class="status"><?= htmlspecialchars($row['status'], ENT_QUOTES, 'UTF-8') ?></span></td>
<td>
<form method="post" class="inline-form">
<input type="hidden" name="application_id" value="<?= (int)$row['id'] ?>">
<select name="status">
<option value="Under Review" <?= $row['status'] === 'Under Review' ? 'selected' : '' ?>>Under Review</option>
<option value="Shortlisted" <?= $row['status'] === 'Shortlisted' ? 'selected' : '' ?>>Shortlisted</option>
<option value="Interview" <?= $row['status'] === 'Interview' ? 'selected' : '' ?>>Interview</option>
<option value="Selected" <?= $row['status'] === 'Selected' ? 'selected' : '' ?>>Selected</option>
<option value="Rejected" <?= $row['status'] === 'Rejected' ? 'selected' : '' ?>>Rejected</option>
</select>
<button class="btn small" type="submit">Update</button>
</form>
</td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>
</main>
</body>
</html>
