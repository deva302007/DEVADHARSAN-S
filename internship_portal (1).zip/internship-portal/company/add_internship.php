<?php
declare(strict_types=1);
session_start();
require_once __DIR__ . '/../config/database.php';

if (!isset($_SESSION['user_id'], $_SESSION['role']) || $_SESSION['role'] !== 'company') {
    header('Location: ../login.php');
    exit;
}

$message = '';
$error = '';
$companyId = 0;

try {
    $stmt = $pdo->prepare(
        'SELECT id FROM companies WHERE user_id = ? LIMIT 1'
    );
    $stmt->execute([(int)$_SESSION['user_id']]);
    $company = $stmt->fetch();

    if (!$company) {
        $create = $pdo->prepare(
            'INSERT INTO companies (user_id, company_name)
             VALUES (?, ?)'
        );
        $create->execute([
            (int)$_SESSION['user_id'],
            $_SESSION['name'] ?? 'Company'
        ]);
        $companyId = (int)$pdo->lastInsertId();
    } else {
        $companyId = (int)$company['id'];
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $title = trim($_POST['title'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $location = trim($_POST['location'] ?? '');
        $skills = trim($_POST['skills'] ?? '');
        $duration = trim($_POST['duration'] ?? '');
        $stipend = trim($_POST['stipend'] ?? '');

        if ($title === '' || $description === '' || $location === '') {
            $error = 'Please fill in the required fields.';
        } else {
            $insert = $pdo->prepare(
                "INSERT INTO internships
                 (company_id, title, description, location, skills, duration, stipend, status)
                 VALUES (?, ?, ?, ?, ?, ?, ?, 'Open')"
            );
            $insert->execute([
                $companyId,
                $title,
                $description,
                $location,
                $skills,
                $duration,
                $stipend
            ]);

            $message = 'Internship posted successfully.';
        }
    }
} catch (Throwable $e) {
    error_log('InternHub add internship error: ' . $e->getMessage());
    $error = 'Unable to save the internship.';
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Add Internship - InternHub</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include __DIR__ . '/company_nav.php'; ?>
<main class="dashboard narrow">
<div class="page-heading">
<div><p class="eyebrow">OPPORTUNITY MANAGEMENT</p><h1>Post an Internship</h1><p>Create a clear and useful internship listing.</p></div>
</div>
<?php if ($message !== ''): ?><div class="alert success"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
<?php if ($error !== ''): ?><div class="alert error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
<div class="form-card">
<form method="post">
<label>Internship Title *</label>
<input type="text" name="title" value="<?= htmlspecialchars($_POST['title'] ?? '', ENT_QUOTES, 'UTF-8') ?>" placeholder="e.g. Full Stack Developer Intern" required>
<label>Description *</label>
<textarea name="description" rows="6" placeholder="Describe responsibilities and requirements..." required><?= htmlspecialchars($_POST['description'] ?? '', ENT_QUOTES, 'UTF-8') ?></textarea>
<div class="form-grid">
<div><label>Location *</label><input type="text" name="location" value="<?= htmlspecialchars($_POST['location'] ?? '', ENT_QUOTES, 'UTF-8') ?>" placeholder="Chennai / Remote" required></div>
<div><label>Skills</label><input type="text" name="skills" value="<?= htmlspecialchars($_POST['skills'] ?? '', ENT_QUOTES, 'UTF-8') ?>" placeholder="PHP, MySQL, JavaScript"></div>
<div><label>Duration</label><input type="text" name="duration" value="<?= htmlspecialchars($_POST['duration'] ?? '', ENT_QUOTES, 'UTF-8') ?>" placeholder="3 Months"></div>
<div><label>Stipend</label><input type="text" name="stipend" value="<?= htmlspecialchars($_POST['stipend'] ?? '', ENT_QUOTES, 'UTF-8') ?>" placeholder="₹10,000 / month"></div>
</div>
<button type="submit" class="btn primary">Publish Internship</button>
</form>
</div>
</main>
</body>
</html>
