InternHub - Fixed PDO Version
=============================

This version converts the student and company pages to PDO so they all use
the same database connection as login.php and register.php.

IMPORTANT
---------
The database password already present in the supplied project was preserved
in config/database.php. If your hosting provider changes that password,
update $dbPass in that file.

PHP START COMMAND
-----------------
php -d extension=./php-ext/mysqlnd.so -d extension=./php-ext/pdo_mysql.so -S 0.0.0.0:8080 -t internship-portal

DATABASE
--------
Host: db01.dbhost.dev
Port: 5051
Database: db_454xyywur
User: user_454xyywur

The database must contain:
users
students
companies
internships
applications

If MySQL returns error 1045, PHP is reaching MySQL but the database server
is rejecting the credentials or remote host. That must be corrected in the
database/hosting panel; application PHP cannot bypass it.

The old db_check.php diagnostic file was removed because it contained a
database credential and is not needed for the working application.
